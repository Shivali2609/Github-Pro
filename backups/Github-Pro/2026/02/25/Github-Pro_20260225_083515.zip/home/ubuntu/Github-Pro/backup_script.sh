#!/bin/bash

# ---------------- CONFIGURATION ----------------

PROJECT_NAME="Github-Pro"
SOURCE_DIR="$HOME/$PROJECT_NAME"
BASE_BACKUP_DIR="$HOME/backups"
GDRIVE_REMOTE="gdrive:Backups/$PROJECT_NAME"
LOG_FILE="$HOME/backups.log"

# Retention Settings
DAILY_RETENTION=7
WEEKLY_RETENTION=4
MONTHLY_RETENTION=3

WEBHOOK_URL="YOUR_REAL_WEBHOOK_URL_HERE"
ENABLE_NOTIFY=true

# ---------------- VALIDATION ----------------

if [ ! -d "$SOURCE_DIR" ]; then
  echo "[$(date)] ERROR: Source directory does not exist" >> "$LOG_FILE"
  exit 1
fi

command -v zip >/dev/null 2>&1 || { echo "zip not installed"; exit 1; }
command -v rclone >/dev/null 2>&1 || { echo "rclone not installed"; exit 1; }

# ---------------- PREPARE DIRECTORIES ----------------

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
YEAR=$(date +"%Y")
MONTH=$(date +"%m")
DAY=$(date +"%d")

BACKUP_DIR="$BASE_BACKUP_DIR/$PROJECT_NAME/$YEAR/$MONTH/$DAY"
mkdir -p "$BACKUP_DIR"

BACKUP_FILE="${PROJECT_NAME}_${TIMESTAMP}.zip"
BACKUP_PATH="$BACKUP_DIR/$BACKUP_FILE"

# ---------------- CREATE BACKUP ----------------

zip -r "$BACKUP_PATH" "$SOURCE_DIR"

if [ $? -ne 0 ]; then
  echo "[$(date)] Backup failed" >> "$LOG_FILE"
  exit 1
fi

echo "[$(date)] Created backup: $BACKUP_FILE" >> "$LOG_FILE"

# ---------------- UPLOAD TO GOOGLE DRIVE ----------------

rclone copy "$BACKUP_PATH" "$GDRIVE_REMOTE"

if [ $? -eq 0 ]; then
  echo "[$(date)] Upload successful" >> "$LOG_FILE"
else
  echo "[$(date)] Upload failed" >> "$LOG_FILE"
  exit 1
fi

# ---------------- ROTATION LOGIC ----------------

BACKUP_ROOT="$BASE_BACKUP_DIR/$PROJECT_NAME"

# Daily retention
find "$BACKUP_ROOT" -type f -name "*.zip" -mtime +$DAILY_RETENTION -delete
echo "[$(date)] Daily retention cleanup done" >> "$LOG_FILE"

# Weekly retention (keep last N Sundays)
mapfile -t WEEKLY_FILES < <(
  find "$BACKUP_ROOT" -type f -name "*.zip" -printf "%T@ %p\n" | sort -nr | awk '{print $2}'
)

COUNT=0
for file in "${WEEKLY_FILES[@]}"; do
  if [ "$(date -r "$file" +%u)" -eq 7 ]; then
    ((COUNT++))
    if [ $COUNT -gt $WEEKLY_RETENTION ]; then
      rm -f "$file"
    fi
  fi
done
echo "[$(date)] Weekly retention cleanup done" >> "$LOG_FILE"

# Monthly retention (keep last N 1st-of-month backups)
mapfile -t MONTHLY_FILES < <(
  find "$BACKUP_ROOT" -type f -name "*.zip" -printf "%T@ %p\n" | sort -nr | awk '{print $2}'
)

COUNT=0
for file in "${MONTHLY_FILES[@]}"; do
  if [ "$(date -r "$file" +%d)" -eq 01 ]; then
    ((COUNT++))
    if [ $COUNT -gt $MONTHLY_RETENTION ]; then
      rm -f "$file"
    fi
  fi
done
echo "[$(date)] Monthly retention cleanup done" >> "$LOG_FILE"

# ---------------- NOTIFICATION ----------------

if [ "$ENABLE_NOTIFY" = true ]; then
  curl -X POST -H "Content-Type: application/json" \
  -d "{\"project\": \"$PROJECT_NAME\", \"date\": \"$TIMESTAMP\", \"status\": \"BackupSuccessful\"}" \
  "$WEBHOOK_URL"

  echo "[$(date)] Notification sent" >> "$LOG_FILE"
fi

echo "[$(date)] Backup completed successfully" >> "$LOG_FILE"
